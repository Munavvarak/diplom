﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace diplom
{
    public partial class Form2 : Form
    {

        private Dictionary<string, string> dishes = new Dictionary<string, string>()
            {
                {"Борщ", "свекла, морковь, картофель, мясо"},
                {"Пицца", "тесто, соус, сыр, колбаса, оливки"},
                {"Салат Цезарь", "курица, салат, помидоры, сыр, соус"},
                // Добавьте другие блюда и их составляющие
            };

        private Random random = new Random();
        private KeyValuePair<string, string> currentDish;

        public Form2()
        {
            InitializeComponent();
            SetRandomDish();
        }

        private void SetRandomDish()
        {
            int index = random.Next(dishes.Count);
            currentDish = dishes.ElementAt(index);
            label1.Text = currentDish.Value;
        }

        private void buttonCheck_Click(object sender, EventArgs e)
        {
            //if (textBox1.Text.ToLower() == currentDish.Key.ToLower())
            //{
            //    MessageBox.Show("Правильно! Это " + currentDish.Key);
            //    SetRandomDish();
            //    textBox1.Text = "";
            //}
            //else
            //{
            //    MessageBox.Show("Неверно. Попробуйте еще раз.");
            //}
        }

        private void buttonCheck_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text.ToLower() == currentDish.Key.ToLower())
            {
                MessageBox.Show("Правильно! Это " + currentDish.Key);
                SetRandomDish();
                textBox1.Text = "";
            }
            else
            {
                MessageBox.Show("Неверно. Попробуйте еще раз.");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }
    }
}

