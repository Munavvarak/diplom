﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace diplom
{
    public partial class Form4 : Form
    {
        private Dictionary<string, List<string>> recipes = new Dictionary<string, List<string>>
        {
            { "Паста карбонара", new List<string> { "спагетти", "гуанчиале", "яйца", "пармезан", "черный перец" } },
            { "Греческий салат", new List<string> { "огурцы", "помидоры", "фета", "оливки", "лук" } },
            // Добавьте еще рецептов
        };

        private KeyValuePair<string, List<string>> currentRecipe;
        private List<string> selectedIngredients = new List<string>();
       
        public Form4()
        {
            InitializeComponent();
            SetRandomRecipe();
        }

        private void SetRandomRecipe()
        {int index = new Random().Next(recipes.Count);
            currentRecipe = recipes.ElementAt(index);
            List<string> falseIngredients = new List<string> { "Соль", "Перец", "Сахар", "Мука", "Лимон", "Чеснок" };
            label1.Text = "Выберите все ингредиенты для блюда: " + currentRecipe.Key;

            checkedListBox1.Items.Clear();

            List<string> allIngredients = recipes.SelectMany(recipe => recipe.Value).Distinct().ToList();

            // Добавляем правильные ингредиенты
            foreach (string ingredient in currentRecipe.Value)
            {
                checkedListBox1.Items.Add(ingredient);
                allIngredients.Remove(ingredient); // Удаляем правильные ингредиенты из общего списка
            }

            // Добавляем ложные ингредиенты
            int falseIngredientsCount = 1; // Количество ложных ингредиентов
            for (int i = 0; i < falseIngredientsCount; i++)
            {
                string falseIngredient = allIngredients[new Random().Next(allIngredients.Count)];
                checkedListBox1.Items.Add(falseIngredient);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {

            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            selectedIngredients.Clear();
            foreach (var item in checkedListBox1.CheckedItems)
            {
                selectedIngredients.Add(item.ToString());
            }

            if (selectedIngredients.SequenceEqual(currentRecipe.Value))
            {
                MessageBox.Show("Поздравляем! Вы правильно выбрали все ингредиенты.");
                SetRandomRecipe();
            }
            else
            {
                MessageBox.Show("Попробуйте еще раз.");

            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            //List<string> falseIngredients = new List<string> { "Соль", "Перец", "Сахар", "Мука", "Лимон", "Чеснок" };

            //foreach (string ingredient in falseIngredients)
            //{
            //    checkedListBox1.Items.Add(ingredient);
            //}
        }
    }
    }

